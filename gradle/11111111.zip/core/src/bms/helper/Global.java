package bms.helper;

public class Global {
    public static String dir="app";
    
    
}

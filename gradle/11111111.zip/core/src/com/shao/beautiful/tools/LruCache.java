package com.shao.beautiful.tools;

import java.util.LinkedHashMap;
import java.util.Map;

public class LruCache<K, V> extends LinkedHashMap<K, V> {

	/**
	 * @param args
	 */
	private static final long serialVersionUID = -479397564067719956L;
	private int size;
	
	public LruCache(int size) {
		super(size, 0.75f, true);
		this.size = size;
	}
	
	public static <K, V> LruCache<K, V> newInstance(int size) {
		return new LruCache<K, V>(size);
	}
	
	public void setMaxSize(int size) {
		this.size = size;
	}
	
	@Override
	protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
		return size() > size;
	}
	
	
}

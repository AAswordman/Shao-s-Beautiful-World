package com.shao.beautiful.gameObj;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.math.Vector3;
import com.shao.beautiful.manager.world.EntityManager;
import com.shao.beautiful.gameObj.model.EntityModel;
import com.shao.beautiful.gameObj.model.ModelGroup;
import bms.helper.tools.Mathbms;
import com.shao.beautiful.tools.LruCache;
import bms.helper.tools.ArrayListSafe;
import java.util.ArrayList;

public class Entity extends GameObj {
    public Vector3 acceleration=new Vector3();
    public Vector3 speed=new Vector3();
    protected EntityManager entityManager;
    protected CollisionBox box;
    protected EntityModel model;

    private LruCache<String,CollisionBox> blockCache=new LruCache<>(8);
    public Entity(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    public void behavior(float delay) {

        physicsMove(delay,5);
    }
    private final Vector3 tmpV=new Vector3();
    private void physicsMove(float delay,int times) {
    	if(times<0)return;
        acceleration.setZero();
        //设置空气阻力加速度
        float k=0.06f;
        acceleration.x = (float) ((speed.x > 0 ?-1: 1) * Math.pow(speed.x, 2) * k);
        acceleration.y = (float) ((speed.y > 0 ?-1: 1) * Math.pow(speed.y, 2) * k);
        acceleration.z = (float) ((speed.z > 0 ?-1: 1) * Math.pow(speed.z, 2) * k);

        //设置重力加速度
        acceleration.y -= 9.8;

        //加速度增加速度
        speed.add(acceleration.scl(delay));

        //方块弹力瞬间加速度
        ArrayListSafe<CollisionBox> boxes=new ArrayListSafe<>(6);
        getRangBlock(boxes, box.getZremoveArea());
        getRangBlock(boxes, box.getZaddArea());
        getRangBlock(boxes, box.getXaddArea());
        getRangBlock(boxes, box.getXremoveArea());
        getRangBlock(boxes, box.getYaddArea());
        getRangBlock(boxes, box.getYremoveArea());
        for (CollisionBox c : boxes) {
            //air
            if (c == null)continue;
            c.generateResistance(box,speed);
        }

        //判断未来的时间中会不会有力突变，如果有则分段计算
        CollisionBox simulatePos=box.copy();
        CollisionBox lastSimulatePos=box.copy();
        final Vector3 stepPos=new Vector3();

        //T/(T*V/0.5)=0.5/Vmax
        float stepTime=(float)(0.25 / Math.max(Math.max(Math.abs(speed.x), Math.abs(speed.y)), Math.abs(speed.z)));
        float time=0;
        float lastTime=0;

        float actTime=0;
        while (time < delay) {
            time = Math.min(time + stepTime, delay);
            float useTime= time-lastTime;
            simulatePos.position.add(stepPos.set(speed).scl(useTime));
            boxes=new ArrayListSafe<>(6);
            getRangBlock(boxes, simulatePos.getZremoveArea());
            getRangBlock(boxes, simulatePos.getZaddArea());
            getRangBlock(boxes, simulatePos.getXaddArea());
            getRangBlock(boxes, simulatePos.getXremoveArea());
            getRangBlock(boxes, simulatePos.getYaddArea());
            getRangBlock(boxes, simulatePos.getYremoveArea());
            
            float earliestCrashingTime=999;
            for (CollisionBox c : boxes) {
                //air
                if (c == null)continue;

                float[] crashingTime=new float[]{0,0,0};
                if (simulatePos.isCrashing(c)) {
                	if (Math.abs(lastSimulatePos.position.x - c.position.x)
                        > c.getHalfWidth() + lastSimulatePos.getHalfWidth()) {
                        //(x动-x静-r1-r2)/-Vx=碰撞时刻
                        crashingTime[0] = (lastSimulatePos.position.x - c.position.x - lastSimulatePos.getHalfWidth() - c.getHalfWidth()) / (-speed.x);
                    }
                    
                    if (Math.abs(lastSimulatePos.position.z - c.position.z)
                        > c.getHalfWidth() + lastSimulatePos.getHalfWidth()) {

                        crashingTime[2] = (lastSimulatePos.position.z - c.position.z - lastSimulatePos.getHalfWidth() - c.getHalfWidth()) / (-speed.z);
                    }
                    
                    if (Math.abs(lastSimulatePos.position.y+lastSimulatePos.getHalfHeight() - c.position.y-c.getHalfHeight())
                        > c.getHalfHeight() + lastSimulatePos.getHalfHeight()) {

                        crashingTime[1] = (lastSimulatePos.position.y+lastSimulatePos.getHalfHeight() - c.position.y-c.getHalfHeight() - lastSimulatePos.getHalfHeight() - c.getHalfHeight()) / (-speed.y);
                    }

                    earliestCrashingTime = Math.min(earliestCrashingTime,
                                                    Math.max(crashingTime[2], Math.max(crashingTime[0], crashingTime[1])));
                }
            }
            if (earliestCrashingTime != 999) {
                actTime = lastTime + earliestCrashingTime;
                break;
            }
            lastTime = time;
            lastSimulatePos = simulatePos.copy();
        }
        
        //速度改变位移
        if (actTime == 0) {
            box.position.add(speed.cpy().scl(delay));
        } else {
            box.position.add(speed.cpy().scl(actTime));
            //box.toAccuracy3();
            //System.out.println(box);
            physicsMove(delay-actTime,times-1);
        }
    }
    public void getRangBlock(ArrayList<CollisionBox> arr, Vector3[] vec) {
        for (int x=(int) Math.floor(vec[0].x);x < vec[1].x;x++) {
            for (int y=(int) Math.floor(vec[0].y);y < vec[1].y;y++) {
                for (int z=(int) Math.floor(vec[0].z);z < vec[1].z;z++) {
                    CollisionBox b=getBlockCollisionBox(x, y, z);
                    if (arr.indexOf(b) == -1) {
                        arr.add(b);
                    }
                }
            }
        }
    }

    public CollisionBox getBlockCollisionBox(int x, int y, int z) {
        String key=x + "|" + y + "|" + z;
        if (blockCache.containsKey(key)) {
            return blockCache.get(key);
        }
        Block b=entityManager.getWorldManager().loader.getBlock(x, y, z);
        if (b.id != 0) {
            CollisionBox box=b.getCollisionBox(x, y, z);
            blockCache.put(key, box);
            return box;
        }
        return null;
    }
    public void render(ModelBatch batch) {
        ModelGroup e=model.copy();
        e.setPosition(box.position.x, box.position.y, box.position.z);
        e.render(batch);
    }
    public void setPosition(float x, float y, float z) {
        box.position.set(x, y, z);
    }
    public Vector3 getPosition() {
        return box.position;
    }
}

package com.shao.beautiful.gameObj;
import com.badlogic.gdx.math.Vector3;

public class CollisionBox {
    public Vector3 position;
    private float h;
    private float w;
    public CollisionBox(float x, float y, float z, float w, float h) {
        this.position = new Vector3(x, y, z);
        this.w = w;
        this.h = h;
    }
    public CollisionBox(){
        
    }
    //返回低点和高点
    public Vector3[] getXremoveArea() {
        return new Vector3[]{new Vector3(position.x - w / 2, position.y, position.z + w / 2),
            new Vector3(position.x - w / 2, position.y + h, position.z + w / 2)};
    }
    public Vector3[] getXaddArea() {
        return new Vector3[]{new Vector3(position.x + w / 2, position.y, position.z + w / 2),
            new Vector3(position.x + w / 2, position.y + h, position.z + w / 2)};
    }
    public Vector3[] getZremoveArea() {
        return new Vector3[]{new Vector3(position.x - w / 2, position.y, position.z - w / 2),
            new Vector3(position.x + w / 2, position.y + h, position.z - w / 2)};
    }
    public Vector3[] getZaddArea() {
        return new Vector3[]{new Vector3(position.x - w / 2, position.y, position.z + w / 2),
            new Vector3(position.x + w / 2, position.y + h, position.z + w / 2)};
    }
    public Vector3[] getYremoveArea() {
        return new Vector3[]{new Vector3(position.x - w / 2, position.y, position.z - w / 2),
            new Vector3(position.x + w / 2, position.y, position.z + w / 2)};
    }
    public Vector3[] getYaddArea() {
        return new Vector3[]{new Vector3(position.x - w / 2, position.y + h, position.z - w / 2),
            new Vector3(position.x + w / 2, position.y + h, position.z + w / 2)};
    }
    public Vector3[] getArea() {
        return new Vector3[]{new Vector3(position.x - w / 2, position.y, position.z - w / 2),
            new Vector3(position.x + w / 2, position.y + h, position.z + w / 2)};
    }
    public Vector3 getCenter() {
        return new Vector3(position.x , position.y+getHalfHeight(), position.z);
    }
    public boolean isCrashing(CollisionBox box){
        Vector3[] a=getArea();
        Vector3[] b=box.getArea();
        
        return a[0].x<=b[1].x&&a[0].y<=b[1].y&&a[0].z<=b[1].z
        && a[1].x>=b[0].x&&a[1].y>=b[0].y&&a[1].z>=b[0].z;
    }
    
    //use to Block
    /*
    public void generateResistance(CollisionBox box){
    	if(!isCrashing(box))return ;
    	Vector3 pos=box.position;
        Vector3 target=box.getCenter();
        Vector3 center=getCenter();
        
        float max=Math.max(Math.max(Math.abs(target.x-center.x),Math.abs(target.y-center.y)),Math.abs(target.z-center.z));
        
        if(Math.abs(target.x-center.x)==max){
            pos.x=target.x-center.x>0?Math.max(pos.x,center.x+getHalfWidth()+box.getHalfWidth()):Math.min(pos.x,center.x-getHalfWidth()-box.getHalfWidth());
        }
        
        if(Math.abs(target.y-center.y)==max){
            pos.y=target.y-center.y>0?Math.max(pos.y,center.y+getHalfHeight()):Math.min(pos.y,center.y-getHalfHeight()-box.h);
        }
        
        if(Math.abs(target.z-center.z)==max){
            pos.z=target.z-center.z>0?Math.max(pos.z,center.z+getHalfWidth()+box.getHalfWidth()):Math.min(pos.z,center.z-getHalfWidth()-box.getHalfWidth());
        }
        
    }
    */
    public void generateResistance(CollisionBox box,Vector3 speed){
        Vector3 target=box.getCenter();
        Vector3 center=getCenter();
        
        float max=Math.max(Math.max(Math.abs(target.x-center.x),Math.abs(target.y-center.y)),Math.abs(target.z-center.z));
        
        if(Math.abs(target.x-center.x)==max){
            speed.x=target.x-center.x>0?Math.max(speed.x,0):Math.min(speed.x,0);
        }
        if(Math.abs(target.y-center.y)==max){
            speed.y=target.y-center.y>0?Math.max(speed.y,0):Math.min(speed.y,0);
        }
        if(Math.abs(target.z-center.z)==max){
            speed.z=target.z-center.z>0?Math.max(speed.z,0):Math.min(speed.z,0);
        }
    }

    
    
    public CollisionBox set(CollisionBox box){
        position=box.position.cpy();
        h=box.h;
        w=box.w;
        return this;
    }
    public CollisionBox set(float x,float y,float z){
        position.x=x;
        position.y=y;
        position.z=z;
        return this;
    }
    public CollisionBox copy(){
        return new CollisionBox().set(this);
    }
    
    public float getHalfWidth(){
        return w/2;
    }
    public float getHalfHeight(){
        return h/2;
    }
    
    @Override
    public boolean equals(Object obj) {
        if(obj==null)return false;
        if(obj instanceof CollisionBox){
            CollisionBox another=(CollisionBox) obj;
            return position.equals(another.position)&&w==another.w&&h==another.h;
        }
        return false;
    }
    @Override
    public String toString() {
    	return position.toString()+"//w="+w+"/h="+h;
    }
    public CollisionBox toAccuracy3(){
    	return set(toAccuracy3(position.x), toAccuracy3(position.y), toAccuracy3(position.z));
    }
    public float toAccuracy3(float f){
    	return Math.round(f*1000)/1000f;
    }
    public float toAccuracy2(float f){
    	return Math.round(f*1000)/1000f;
    }
	public CollisionBox toAccuracy2() {
		return set(toAccuracy2(position.x), toAccuracy2(position.y), toAccuracy2(position.z));
		 
	}
}

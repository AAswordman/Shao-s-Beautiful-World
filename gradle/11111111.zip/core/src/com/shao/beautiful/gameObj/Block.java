package com.shao.beautiful.gameObj;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.FloatAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute;
import com.badlogic.gdx.graphics.g3d.utils.MeshPartBuilder;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.collision.BoundingBox;
import com.shao.beautiful.tools.TextureManager;
import java.util.HashMap;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.Camera;

public class Block extends GameObj {
    public int id;
    
    public Block(int id) {
        this.id = id;
        build(blockTextureGetter.get(id).texture);

    }
    public ModelInstance[] block;
    private BoundingBox bounds = new BoundingBox();
    private float r;
    public static int 
    FACE_TOP=3,
    FACE_BOTTOM=2,
    FACE_BEHIND=0,
    FACE_FRONT=1,
    FACE_LEFT=4,
    FACE_RIGHT=5,
    FACE_RESTART=6;
    /*
     public void build() {
     ModelBuilder modelBuilder = new ModelBuilder();
     block = new ModelInstance(modelBuilder.createBox(1f, 1f, 1f,
     new Material(ColorAttribute.createDiffuse(Color.GREEN)),

     VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal));


     block.calculateBoundingBox(bounds);
     //r=bounds.getDimensions().len()/2;
     }
     public void build(String p) {
     FileHandle p1=Gdx.files.internal(p);
     ModelBuilder modelBuilder = new ModelBuilder();
     block = new ModelInstance(modelBuilder.createBox(1f, 1f, 1f,
     new Material(TextureAttribute.createDiffuse(TextureManager.get(p1)),
     new BlendingAttribute(),
     FloatAttribute.createAlphaTest(0.25f)),
     VertexAttributes.Usage.Position | VertexAttributes.Usage.TextureCoordinates));


     block.calculateBoundingBox(bounds);
     //r=bounds.getDimensions().len()/2;
     }
     */
    public void build(String[] pp) {
        ModelBuilder modelBuilder = new ModelBuilder();
        FileHandle[] p1=new FileHandle[]{
            Gdx.files.internal(pp[0]),
            Gdx.files.internal(pp[1]),
            Gdx.files.internal(pp[2]),
            Gdx.files.internal(pp[3]),
            Gdx.files.internal(pp[4]),
            Gdx.files.internal(pp[5])
        };
        
        Texture[] texture=new Texture[]{
            TextureManager.get(p1[0]),
            TextureManager.get(p1[1]),
            TextureManager.get(p1[2]),
            TextureManager.get(p1[3]),
            TextureManager.get(p1[4]),
            TextureManager.get(p1[5])
        };
        int attr = VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal | VertexAttributes.Usage.TextureCoordinates;
        float[][] p=new float[][]{
            new float[]{0,0,0},
            new float[]{1,0,0},
            new float[]{0,1,0},
            new float[]{1,1,0},
            new float[]{0,0,1},
            new float[]{1,0,1},
            new float[]{0,1,1},
            new float[]{1,1,1}
        };
        block = new ModelInstance[6];

        block[0] = buildPart(p[1],p[0],p[2],p[3],  0, 0, -1, modelBuilder, attr, texture[0]);
        block[1] = buildPart(p[4],p[5],p[7],p[6],  0, 0, 1, modelBuilder, attr, texture[1]);
        block[2] = buildPart(p[4],p[0],p[1],p[5], 0, -1, 0, modelBuilder, attr, texture[2]);
        block[3] = buildPart(p[6],p[7],p[3],p[2],  0, 1, 0, modelBuilder, attr, texture[3]);
        block[4] = buildPart(p[0],p[4],p[6],p[2], -1, 0, 0, modelBuilder, attr, texture[4]);
		block[5] = buildPart(p[5],p[1],p[3],p[7], 1, 0, 0, modelBuilder, attr, texture[5]);
        /*
         block[0] = buildPart(p[0], p[2], p[3], p[1], 0, 0, 1, modelBuilder, attr, TextureManager.get(Gdx.files.internal("dirt.png")));
         block[1] = buildPart(p[5], p[7], p[6], p[4], 0, 0, -5, modelBuilder, attr, texture);
         block[2] = buildPart(p[4], p[6], p[2], p[0], 1, 0, 0, modelBuilder, attr, TextureManager.get(Gdx.files.internal("grass_side_carried.png")));
         block[3] = buildPart(p[1], p[3], p[7], p[5], -1, 0, 0, modelBuilder, attr, TextureManager.get(Gdx.files.internal("grass_side_carried.png")));
         block[4] = buildPart(p[2], p[6], p[7], p[3], 0, -1, 0, modelBuilder, attr, TextureManager.get(Gdx.files.internal("grass_side_carried.png")));
         block[5] = buildPart(p[1], p[5], p[4], p[0], 0, 1, 0, modelBuilder, attr, TextureManager.get(Gdx.files.internal("grass_side_carried.png")));
         */
    }

    private ModelInstance buildPart(float p0, float p1, float p2, float p3, float p4, float p5, float p6, float p7, float p8, float p9, float p10, float p11, int p12, int p13, int p14, ModelBuilder modelBuilder, int attr, Texture texture) {
        modelBuilder.begin();
        modelBuilder.part("box", GL20.GL_TRIANGLES, attr, new Material(TextureAttribute.createDiffuse(texture)))
            .rect(p0, p1, p2,
                  p3, p4, p5,
                  p6, p7, p8,
                  p9, p10, p11,
                  p12, p13, p14
                  );
        return new ModelInstance(modelBuilder.end());
    }

    private ModelInstance buildPart(float[] p1, float[] p2, float[] p3, float[] p4, float a, float b, float c, ModelBuilder modelBuilder, int attr, Texture texture) {
        modelBuilder.begin();
        modelBuilder.part("box", GL20.GL_TRIANGLES, attr, new Material(TextureAttribute.createDiffuse(texture)))
            . rect(p1[0], p1[1], p1[2],
                   p2[0], p2[1], p2[2],
                   p3[0], p3[1], p3[2],
                   p4[0], p4[1], p4[2],
                   a, b, c
                   );
        return new ModelInstance(modelBuilder.end());
    }

    public Block(FileHandle p1, FileHandle p2, FileHandle p3
                 , FileHandle p4, FileHandle p5, FileHandle p6) {

    }
    public Block setPos(float p1, float p2, float p3) {
        for (ModelInstance b: block) {
            b.transform.setToTranslation(p1, p2, p3);
        }
        return this;
    }
    public void setPos(Vector3 p1) {
        for (ModelInstance b: block) {
            b.transform.setToTranslation(p1);
        }
	}
    public void render(ModelBatch modelBatch) {
        for (ModelInstance b: block) {
            modelBatch.render(b);
        }
    }
    public ModelFace getModelFace(int x, int y, int z, int face) {
        return new ModelFace(block[face], x, y, z);
    }
    
    public CollisionBox getCollisionBox(int x,int y,int z){
        return new CollisionBox(x+0.5f,y,z+0.5f,1,1);
    }
    
    public enum BlockTexture {
        NULL(-1,BlockTexture.TYPE_AAAAAA,"grass_carried.png"),
        AIR(0,BlockTexture.TYPE_AAAAAA,"grass_carried.png"),
        DIRT(1,BlockTexture.TYPE_AAAAAA,"dirt.png"),
        GRASS(2,BlockTexture.TYPE_ABBBBC,"grass_carried.png","grass_side_carried.png","dirt.png");
        private String[] texture;
        private int id;;

        public static final int 
        TYPE_AAAAAA=0,
        TYPE_ABBBBC=1,
        TYPE_ABCDEF=2,
        TYPE_ABCBCD=3;

        BlockTexture(int id,int type,String... texture){
            this.id=id;
            //this.texture=texture;
            this.texture=new String[6];
            switch(type){
                case TYPE_ABBBBC:
                    this.texture[FACE_TOP]=texture[0];
                    this.texture[FACE_FRONT]=texture[1];
                    this.texture[FACE_RIGHT]=texture[1];
                    this.texture[FACE_BEHIND]=texture[1];
                    this.texture[FACE_LEFT]=texture[1];
                    this.texture[FACE_BOTTOM]=texture[2];
                    break;
                case TYPE_AAAAAA:
                    this.texture[FACE_TOP]=texture[0];
                    this.texture[FACE_FRONT]=texture[0];
                    this.texture[FACE_RIGHT]=texture[0];
                    this.texture[FACE_BEHIND]=texture[0];
                    this.texture[FACE_LEFT]=texture[0];
                    this.texture[FACE_BOTTOM]=texture[0];
                    break;
                case TYPE_ABCDEF:
                    this.texture[FACE_TOP]=texture[0];
                    this.texture[FACE_FRONT]=texture[1];
                    this.texture[FACE_RIGHT]=texture[2];
                    this.texture[FACE_BEHIND]=texture[3];
                    this.texture[FACE_LEFT]=texture[4];
                    this.texture[FACE_BOTTOM]=texture[5];
                    break;
                case TYPE_ABCBCD:
                    this.texture[FACE_TOP]=texture[0];
                    this.texture[FACE_FRONT]=texture[1];
                    this.texture[FACE_RIGHT]=texture[2];
                    this.texture[FACE_BEHIND]=texture[1];
                    this.texture[FACE_LEFT]=texture[2];
                    this.texture[FACE_BOTTOM]=texture[3];
                    break;
            }
        }
    }
    public static HashMap<Integer,BlockTexture> blockTextureGetter=new HashMap<>();
    static{
        for (BlockTexture b:BlockTexture.values()) {
            blockTextureGetter.put(b.id, b);
        }

    }
    public static class ModelFace {
        private ModelInstance face;
        private BoundingBox bounds = new BoundingBox();
        public int x;
        public int y;
        public int z;
        private float r;
        public void render(ModelBatch mb) {
            face.transform.setTranslation(x, y, z);
            mb.render(face);
        }
        /*
        public ModelInstance getModel(){
            face.transform.setTranslation(x, y, z);
            return face.copy();
        }
        */
        public ModelFace(ModelInstance m, int x, int y, int z) {
            this.x = x;this.y = y;
            this.z = z;this.face = m;
            m.calculateBoundingBox(bounds);
            this.r = bounds.getDimensions(new Vector3(x, y, z)).len();
        }
        public boolean isVisible(final Camera camx) {
            return camx.frustum.sphereInFrustum(new Vector3(x, y, z), r);
        }
    }
}

package com.shao.beautiful.gameObj;

public class EntityManager {
    
    
    
}
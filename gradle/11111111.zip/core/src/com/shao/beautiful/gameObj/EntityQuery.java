package com.shao.beautiful.gameObj;

public class EntityQuery {
    
    
    
}
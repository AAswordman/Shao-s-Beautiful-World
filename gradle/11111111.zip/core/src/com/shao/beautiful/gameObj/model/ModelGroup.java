package com.shao.beautiful.gameObj.model;
import java.util.ArrayList;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.shao.beautiful.gameObj.ModelBatchEnvironment;

public class ModelGroup {
    public String name;
    public ArrayList<ModelBone> bones;
    public ArrayList<ModelGroup> groups;
    private float x;
    private float z;
    private float y;
    public ModelGroup(String name,float x,float y,float z){
        bones=new ArrayList<>();
        
        groups=new ArrayList<>();
        this.name=name;
        this.x=x;
        this.z=z;
        this.y=y;
        
    }
    public ModelGroup add(ModelBone m){
        bones.add(m);
        return this;
    }
    public ModelGroup add(ModelGroup m){
        groups.add(m);
        return this;
    }
    public void render(ModelBatch batch){
        for(ModelGroup m:groups){
            m.render(batch);
        }
        for(ModelBone b:bones){
            batch.render(b.get());
            
        }
        
    }
    public ModelGroup copy(){
        ModelGroup m=new ModelGroup(name,x,y,z);
        for(ModelGroup g:groups){
            m.add(g.copy());
        }
        for(ModelBone b:bones){
            m.add(b.copy());
        }
        return m;
    }
    public void setPosition(float x,float y,float z){
        for(ModelGroup g:groups){
            g.setPosition(x,y,z);
        }
        for(ModelBone b:bones){
            b.setPosition(x,y,z);
        }
    }
}

package com.shao.beautiful.gameObj;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Cubemap;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.RenderableProvider;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.CubemapAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalShadowLight;
import com.badlogic.gdx.graphics.g3d.utils.DepthShaderProvider;
import com.shao.beautiful.tools.EnvironmentCubemap;

public class ModelBatchEnvironment extends ModelBatch {
    private DirectionalShadowLight shadowLight;
    private Environment environment;

    private ModelBatch shadowBatch;

    private EnvironmentCubemap envCubemap;
    public ModelBatchEnvironment(){
        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.4f, 0.4f, 0.4f, 1f));//环境光
        environment.add((shadowLight= new DirectionalShadowLight(4096, 4096, 60f, 60f, .1f, 50f)).set(0.9f, 0.9f, 0.45f, -1f, -0.8f, -0.2f));//直线光源
        environment.set(new ColorAttribute(ColorAttribute.Fog, 0.6f, 0.9f, 0.9f, 1f));
        
        environment.shadowMap = shadowLight;
        /*
        envCubemap = new EnvironmentCubemap(new Pixmap(Gdx.files.internal("cubemap/cubemap_2.png")),
                                            new Pixmap(Gdx.files.internal("cubemap/cubemap_0.png")),
                                            new Pixmap(Gdx.files.internal("cubemap/cubemap_4.png")),
                                            new Pixmap(Gdx.files.internal("cubemap/cubemap_5.png")),
                                            new Pixmap(Gdx.files.internal("cubemap/cubemap_1.png")),
                                            new Pixmap(Gdx.files.internal("cubemap/cubemap_3.png")));
        */
        /*
        Cubemap cubemap = new Cubemap(Gdx.files.internal("cubemap/cubemap_2.png"), 
                                      Gdx.files.internal("cubemap/cubemap_0.png"), 
                                      Gdx.files.internal("cubemap/cubemap_4.png"), 
                                      Gdx.files.internal("cubemap/cubemap_5.png"), 
                                      Gdx.files.internal("cubemap/cubemap_1.png"), 
                                      Gdx.files.internal("cubemap/cubemap_3.png"));
        environment.set(new CubemapAttribute(CubemapAttribute.EnvironmentMap, cubemap));
        */
        shadowBatch = new ModelBatch(new DepthShaderProvider());
        
    }
    @Override
    public void render(RenderableProvider renderable) {
        shadowBatch.render(renderable);
        super.render(renderable,environment);
    }
    public void renderWithOutShadow(RenderableProvider renderable){
        shadowBatch.render(renderable);
        super.render(renderable);
    }
    
    @Override
    public void begin(Camera cam) {
        //envCubemap.render(cam);
        //shadowLight.update(cam);
        shadowLight.begin(cam.position, cam.direction);
        shadowBatch.begin(shadowLight.getCamera());
        super.begin(cam);
    }

    @Override
    public void end() {
        shadowBatch.end();
        shadowLight.end();
        super.end();
        
    }
    
}

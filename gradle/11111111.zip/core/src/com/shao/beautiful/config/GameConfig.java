package com.shao.beautiful.config;

public class GameConfig {
    
    
    
}

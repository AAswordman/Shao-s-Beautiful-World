package com.shao.beautiful.manager.world;
import com.shao.beautiful.manager.WorldManager;
import com.shao.beautiful.gameObj.Block;
import com.shao.beautiful.manager.world.generate.FlatGenerate;
import bms.helper.tools.LOG;
import bms.helper.tools.TimeDelayer;

import com.shao.beautiful.manager.world.generate.NoiseGenerate;
import com.shao.beautiful.manager.world.generate.TerrainGenerate;
import com.shao.beautiful.tools.BlockManager;

public class MapLoader {

    private WorldManager worldManager;

    private TerrainGenerate generate;
    public MapLoader(WorldManager worldManager) {
        this.worldManager = worldManager;
        this.generate = new NoiseGenerate(this);
    }

    public void destroy() {

    }
    public int getHigh(int x, int z) {
        return 0;
    }
    public void putChunkIfNon(int chunkX, int chunkY, int chunkZ) {
    	
        Chunk c=getChunk(chunkX,
                         chunkY ,
                         chunkZ);

        if (c == null) {
            worldManager.saver.putChunk(chunkX, chunkY, chunkZ, (c = generate.getChunk(chunkX, chunkY, chunkZ)));
            
        }
        
    }
    public Chunk getChunkAndGenerate(int chunkX, int chunkY, int chunkZ) {
        Chunk c=getChunk(chunkX, chunkY, chunkZ);

        if (c == null) {
            worldManager.saver.putChunk(chunkX, chunkY, chunkZ, (c = generate.getChunk(chunkX, chunkY, chunkZ)));
        }
        return c;
    }
    public Block getBlock(double x, double y, double z) {

        int chunkX=(int)Math.floor(x / Chunk.width);
        int chunkY=(int)Math.floor(y / Chunk.width);
        int chunkZ=(int)Math.floor(z / Chunk.width);
        Chunk c=getChunk(chunkX, chunkY, chunkZ);
        if (c == null) {
            return BlockManager.get(-1);
        }
        return 
            c.getBlock(mod(x , Chunk.width),
                       mod(y , Chunk.width),
                       mod(z , Chunk.width));
    }

    public Chunk getChunk(int chunkX, int chunkY, int chunkZ) {
        Chunk c=worldManager.saver.getChunk(chunkX,
                                            chunkY ,
                                            chunkZ);
        if(c==null){
            return c;
        }
        if(c.faceData!=null){
            return c;
        }
        byte[] b;
        if((b=worldManager.saver.getRenderFace(chunkX,chunkY,chunkZ))!=null){
            c.setRenderFace(b);
        }
        return c;
    }
    public void putBlockPlayer(int x, int y, int z) {

    }
    private int mod(double a, double b) {
        //LOG.print(a+"",b+"");
        return (int)(a - Math.floor(a / b) * b);
    }
}

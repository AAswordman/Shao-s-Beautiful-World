package com.shao.beautiful.manager.world;
import com.shao.beautiful.manager.WorldManager;
import com.shao.beautiful.gameObj.entities.Player;
import com.badlogic.gdx.graphics.g3d.ModelBatch;

public class EntityManager {

    private WorldManager worldManager;
    private Player player;
    public EntityManager(WorldManager worldManager){
        this.worldManager=worldManager;
        this.player=new Player(this);
        player.setPosition(2,50,2);
    }
    public WorldManager getWorldManager(){
        return worldManager;
    }
    public Player getPlayer(){
        return player;
    }
    public void step(float delay){
        player.behavior(delay);
        
    }
    public void render(ModelBatch m){
        player.render(m);

    }
}

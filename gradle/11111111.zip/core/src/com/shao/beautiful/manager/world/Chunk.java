package com.shao.beautiful.manager.world;

import com.shao.beautiful.gameObj.Block;
import java.util.HashMap;
import bms.helper.tools.LOG;
import com.shao.beautiful.tools.BlockManager;
import java.util.ArrayList;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import bms.helper.tools.ArrayListSafe;
import com.shao.beautiful.gameObj.FaceData;
import com.shao.beautiful.tools.FaceDataManager;
import java.nio.ByteBuffer;

public class Chunk {
    public static int width=16;
    public volatile ByteBuffer blockData;
    public volatile ByteBuffer faceData;
    public boolean isEdit=true;
    public ArrayListSafe<Block.ModelFace> renderFace=new ArrayListSafe<>();
    public ModelInstance mixModel;
    public Chunk(byte[] data) {
        blockData = ByteBuffer.wrap(data);
        /*
         for(int x=0;x<width;x++){
         for(int z=0;z<width;z++){
         int high=0;
         }
         }
         */
    }

    public byte[] toByteArray() {
        return blockData.array();
    }
    public void setRenderFace(byte[] renderData) {
        faceData = ByteBuffer.wrap(renderData);
    }
    
    public Block getBlock(int x, int y, int z) {
        //LOG.print("x|y|z",x+"|"+y+"|"+z);
        return BlockManager.get(blockData.get(getBlockPosition(x, y, z)) & 0xff);
    }
    public FaceData getFaceData(int x, int y, int z) {
        //LOG.print("x|y|z",x+"|"+y+"|"+z);
        return FaceDataManager.get(faceData.get(getBlockPosition(x, y, z)) & 0xff);
    }
    public void setFaceData(int x, int y, int z, FaceData f) {
        faceData.put(getBlockPosition(x, y, z), f.getData());
        //不必重新刷新渲染的面
        
    }
    public void setBlock(int x, int y, int z, Block b) {
        blockData.put(getBlockPosition(x, y, z), (byte)(b.id & 0xff));
    }
    public static int getBlockPosition(int x, int y, int z) {
        return z * width * width + x * width + y;
    }

    @Override
    public String toString() {
        return "Chunk: ";
    }

}

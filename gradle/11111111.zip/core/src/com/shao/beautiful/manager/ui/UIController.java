package com.shao.beautiful.manager.ui;
import com.shao.beautiful.manager.WorldManager;
import com.badlogic.gdx.math.Vector2;

public class UIController {
    private WorldManager worldManager;
    public UIController(WorldManager worldManager){
        this.worldManager=worldManager;
    }

    public void move(Vector2 scl) {
        worldManager.entities.getPlayer().speed.set(
        		scl.x,worldManager.entities.getPlayer().speed.y,scl.y
        		);
    }
    public void move(float x,float z){
        
    }
    
}

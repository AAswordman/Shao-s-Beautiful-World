package com.shao.beautiful.manager;

public interface StepAble {
    void step(float delay);
    
    
}

package com.shao.beautiful.manager.world.generate;

import com.shao.beautiful.manager.world.MapLoader;
import com.shao.beautiful.manager.world.Chunk;
import com.shao.beautiful.gameObj.Block;
import com.mithrilmania.blocktopograph.util.Noise;
import bms.helper.tools.LOG;
import com.shao.beautiful.tools.BlockManager;

public class NoiseGenerate implements TerrainGenerate {

    public static Noise noise;

    @Override
    public Chunk getChunk(int chunkX, int chunkY, int chunkZ) {
        Chunk c=new Chunk(new byte[Chunk.width * Chunk.width * Chunk.width]);
        if (chunkY < 0)return c;
        for (int x=0;x < Chunk.width;x++) {
            for (int z=0;z < Chunk.width;z++) {
                int high=(int) ((noise.noise((chunkX * Chunk.width + x)*0.01, (chunkZ * Chunk.width + z)*0.01)+0.3) * (double)100);
                for (int y=0;y < Chunk.width;y++) {
                    
                    
                    if (chunkY * Chunk.width + y == high) {
                        c.setBlock(x, y, z, BlockManager.get(2));
                    } else if (chunkY * Chunk.width + y < high) {
                        c.setBlock(x, y, z, BlockManager.get(1));
                    }
                }

            }
        }

        return c;
    }
    private MapLoader loader;
    public NoiseGenerate(MapLoader loader) {
        this.loader = loader;
        this.noise = new Noise(100);
    }


}

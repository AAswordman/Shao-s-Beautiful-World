package com.shao.beautiful.manager.world;

import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.math.Vector3;
import com.shao.beautiful.gameObj.Block;
import com.shao.beautiful.manager.UIManager;
import com.shao.beautiful.manager.WorldManager;
import com.shao.beautiful.tools.BlockManager;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import com.shao.beautiful.tools.FaceDataManager;

import bms.helper.tools.TimeDelayer;

import com.shao.beautiful.gameObj.FaceData;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g3d.Model;
import bms.helper.tools.LOG;

public class MapRenderer {

	private WorldManager worldManager;

	private boolean first = true;
	public int chunkLoadNum = 3;
	private boolean isLoadOver = true;

	public MapRenderer(WorldManager worldManager) {
		this.worldManager = worldManager;
	}

	public void loadRenderFace(int chunkX, int chunkY, int chunkZ) {

		Chunk c = worldManager.loader.getChunk(chunkX, chunkY, chunkZ);
		int pos = 0;
		if (c.isEdit) {
			c.isEdit = false;
			c.renderFace.clear();
			if (c.faceData == null) {
				TimeDelayer timer = new TimeDelayer(100);
				timer.GetDelay();

				boolean save = true;
				byte[] faceData = new byte[Chunk.width * Chunk.width * Chunk.width];
				for (int z = 0; z < Chunk.width; z++) {
					for (int x = 0; x < Chunk.width; x++) {
						for (int y = 0; y < Chunk.width; y++) {

							int id = c.blockData.get(pos);
							if (id != 0) {
								Block f = BlockManager.get(id);
								FaceData data = new FaceData();
								int nx = chunkX * Chunk.width + x;
								int ny = chunkY * Chunk.width + y;
								int nz = chunkZ * Chunk.width + z;
								// Block b;
								int pid;

								pid = (worldManager.loader.getBlock(nx - 1, ny, nz)).id;
								save = save && pid != -1;
								if (pid == 0 || pid == -1) {
									data.addFace(Block.FACE_LEFT);
								}
								pid = (worldManager.loader.getBlock(nx + 1, ny, nz)).id;
								save = save && pid != -1;
								if (pid == 0 || pid == -1) {
									data.addFace(Block.FACE_RIGHT);
								}
								pid = (worldManager.loader.getBlock(nx, ny + 1, nz)).id;
								save = save && pid != -1;
								if (pid == 0 || pid == -1) {
									// LOG.print("发现",nx+"/"+ny+"/"+nz);
									data.addFace(Block.FACE_TOP);
								}
								pid = (worldManager.loader.getBlock(nx, ny - 1, nz)).id;
								save = save && pid != -1;
								if (pid == 0 || pid == -1) {
									data.addFace(Block.FACE_BOTTOM);
								}
								pid = (worldManager.loader.getBlock(nx, ny, nz + 1)).id;
								save = save && pid != -1;
								if (pid == 0 || pid == -1) {
									data.addFace(Block.FACE_FRONT);
								}
								pid = (worldManager.loader.getBlock(nx, ny, nz - 1)).id;
								save = save && pid != -1;
								if (pid == 0 || pid == -1) {
									data.addFace(Block.FACE_BEHIND);
								}
								// batch.render(BlockManager.get(id).setPos(chunkX,chunkY,chunkZ).block);
								faceData[pos] = data.getData();
							}
							pos++;

						}
						// LOG.print("使用时间",z+"/"+x +"/"+ timer.GetDelay());
					}

				}
				c.setRenderFace(faceData);
				// LOG.print("使用时间总体" ,""+ timer.GetDelay());
				if (save) {
					worldManager.saver.putRenderFace(chunkX, chunkY, chunkZ, faceData);
				} else {
					c.isEdit = true;
				}

			}
			pos = 0;

			for (int z = 0; z < Chunk.width; z++) {
				for (int x = 0; x < Chunk.width; x++) {
					for (int y = 0; y < Chunk.width; y++) {

						FaceData face = FaceDataManager.get(c.faceData.get(pos));
						Block b = BlockManager.get(c.blockData.get(pos));

						int nx = chunkX * Chunk.width + x;
						int ny = chunkY * Chunk.width + y;
						int nz = chunkZ * Chunk.width + z;
						// Block b;
						for (int i = 0; i < 6; i++) {
							if (face == null)
								continue;
							if (face.analysisFace(i))
								c.renderFace.add(b.getModelFace(nx, ny, nz, i));

						}
						pos++;
					}

				}

			}

		}
	}

	private void load(final int playerChunkX, final int playerChunkY, final int playerChunkZ) {
		if (isLoadOver) {
			isLoadOver = false;
			new Thread(new Runnable() {

				private ArrayBlockingQueue arrayBlockingQueue;

				private ThreadFactory namedThreadFactory;

				private ThreadPoolExecutor tdpool;

				@Override
				public void run() {
					arrayBlockingQueue = new ArrayBlockingQueue(chunkLoadNum * chunkLoadNum);
					namedThreadFactory = new ThreadFactory() {
						@Override
						public Thread newThread(Runnable p1) {
							return new Thread(p1);
						}
					};

					tdpool = new ThreadPoolExecutor(6, 15, 20, TimeUnit.SECONDS, arrayBlockingQueue, namedThreadFactory,
							new ThreadPoolExecutor.CallerRunsPolicy());
					for (int chunkX = playerChunkX - chunkLoadNum; chunkX <= playerChunkX + chunkLoadNum; chunkX++) {
						for (int chunkY = playerChunkY - chunkLoadNum; chunkY <= playerChunkY
								+ chunkLoadNum; chunkY++) {
							final int fchunkY = chunkY;
							final int fchunkX = chunkX;
							Runnable run = namedThreadFactory.newThread(new Runnable() {
								@Override
								public void run() {
									for (int chunkZ = playerChunkZ - chunkLoadNum; chunkZ <= playerChunkZ
											+ chunkLoadNum; chunkZ++) {
										worldManager.loader.putChunkIfNon(fchunkX, fchunkY, chunkZ);
										loadRenderFace(fchunkX, fchunkY, chunkZ);
									}
								}
							});
							tdpool.execute(run);
						}
					}

					tdpool.shutdown();
					while (true) {
						if (tdpool.isTerminated()) {

							break;
						}
					}

					isLoadOver = true;
				}
			}).start();

		}
	}

	public void render(ModelBatch batch, UIManager ui) {
		Vector3 position = worldManager.entities.getPlayer().getPosition();

		int playerChunkX = (int) Math.floor(position.x / Chunk.width);
		int playerChunkY = (int) Math.floor(position.y / Chunk.width);
		int playerChunkZ = (int) Math.floor(position.z / Chunk.width);
		load(playerChunkX, playerChunkY, playerChunkZ);
		// LOG.print("坐标",playerChunkX+"/"+playerChunkY+"/"+playerChunkZ);
		for (int chunkX = playerChunkX - chunkLoadNum; chunkX <= playerChunkX + chunkLoadNum; chunkX++) {

			for (int chunkY = playerChunkY - chunkLoadNum; chunkY <= playerChunkY + chunkLoadNum; chunkY++) {
				for (int chunkZ = playerChunkZ - chunkLoadNum; chunkZ <= playerChunkZ + chunkLoadNum; chunkZ++) {

					Chunk c = worldManager.loader.getChunk(chunkX, chunkY, chunkZ);

					if (c != null) {
						c.renderFace.lock();
						try {
							for (Block.ModelFace m : c.renderFace) {
								if (m == null)
									continue;
								if (m.isVisible(ui.cam)) {
									m.render(batch);
								}
							}
						} catch (Exception e) {
							// TODO: handle exception
						}
						c.renderFace.unlock();
					}
					// LOG.print("时间间隔（一个区块）",worldManager. timeDelayer.GetDelay()+"");
					/*
					 * int pos=0; for(int z=0;z<Chunk.width;z++){ for(int x=0;x<Chunk.width;x++){
					 * for(int y=0;y<Chunk.width;y++){ int id=c.blockData.get(pos); if(id!=0){ }
					 * pos++; } } }
					 */
				}
			}
		}
		this.first = false;
	}

}

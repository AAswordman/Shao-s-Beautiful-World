package com.shao.beautiful.manager;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g3d.utils.CameraInputController;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.shao.beautiful.manager.ui.UIController;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.math.Vector2;
import com.shao.beautiful.gameObj.entities.Player;

public class UIManager implements StepAble {
    public PerspectiveCamera cam;

    private CameraInputController camController;
    private InputMultiplexer inputMultiplexer;
    public UIController controller;
    private Stage stage;
    private int standardLong;

    private boolean isMoving;

    //临时
    private final float movement=3;
    private final Vector2 moveVec=new Vector2();

    private WorldManager worldManager;


    public void resize() {
        cam.viewportHeight = Gdx.graphics.getHeight();
        cam.viewportWidth = Gdx.graphics.getWidth();
        //67可以理解成一个定值，视角宽度（67度）
        cam.near = 0.1f;
        cam.far = 140f;
        cam.position.set(0f, 20f, 0f);
        cam.update();
        stage.clear();
        loadStandardLong();
        
        createUI(stage);
    }

    private void loadStandardLong() {
        this.standardLong = Gdx.graphics.getHeight() / 20;
    }

    public void render(Stage stage) {
        stage.act();
        stage.draw();
    }

    public void createUI(Stage stage) {
        this.stage = stage;
        
        inputMultiplexer.addProcessor(0, stage);
        
        for (FileHandle f: Gdx.files.internal("q").parent().list()) {
        	System.out.println(f.path());
        }
        final float dec_position=standardLong / 2;
        final float dec_size=standardLong * 8;

        final float center_position=dec_position + dec_size / 2;
        final float center_size=standardLong * 2;

        System.out.println(Gdx.files.internal("q").parent().file().getAbsolutePath());
        final Texture direction_tex = new Texture(Gdx.files.internal("direction_move1.png"));
        final Texture direction_cen = new Texture(Gdx.files.internal("direction_move2.png"));;
        Actor direction_bar = new Actor(){
            public void draw(Batch batch, float parentAlpha) {
                batch.draw(direction_tex, getX(), getY(), getWidth(), getHeight());


                batch.draw(direction_cen,
                           center_position - center_size / 2 + moveVec.x,
                           center_position - center_size / 2 + moveVec.y,
                           center_size, center_size);
            }
        };
        direction_bar.setSize(dec_size, dec_size);
        direction_bar.setPosition(dec_position, dec_position);
        direction_bar.addListener(new InputListener() {
                public float limit(float a, float b, float c) {
                    return Math.min(Math.max(a, b), c);
                }
                public void touchDragged(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y, int pointer) {
                    moveVec.x = limit(- dec_size / 2, x - dec_position - dec_size / 2,  dec_size / 2);
                    moveVec.y = limit(- dec_size / 2, y - dec_position - dec_size / 2,  dec_size / 2);
                }
                public boolean touchDown(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y, int pointer, int button) {

                    isMoving = true;
                    moveVec.x = x - dec_position - dec_size / 2;
                    moveVec.y = y - dec_position - dec_size / 2;

                    return true;
                }
                public void touchUp(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y, int pointer, int button) {
                    isMoving = false;
                    moveVec.setZero();
                }

            });
        /*
         * 第 4 步: 添加 button 到舞台
         */
        System.out.println(dec_position);
        stage.addActor(direction_bar);
    }
    private final Vector3 tmpPos=new Vector3();
    //3D视角
    @Override
    public void step(float delay) {
        camController.target = cam.position;
        cam.update();
        camController.update();
        
        Player player=worldManager.entities.getPlayer();
        cam.position.set(tmpPos.set(player.getPosition()).add(-10,20,-20));
        cam.lookAt(player.getPosition());
        if (isMoving) {
            move(delay);
        }
        //cam.position.x+=delay*2;
        //cam.position.z+=delay*2;

        //cam.position.y=(float) NoiseGenerate.noise.noise(cam.position.x*0.01,cam.position.z*0.01)*100+30;
        //LOG.print("摄像机高度",cam.position.y+"");
    }
    public UIManager(WorldManager worldManager) {

        cam = new PerspectiveCamera(67, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());//67可以理解成一个定值，视角宽度（67度）
        cam.position.set(0f, 20f, 0f);

        cam.near = 0f;
        cam.far = 140f;
        cam.update();
        loadStandardLong();
        inputMultiplexer = new InputMultiplexer();
        camController = new CameraInputController(cam);

        inputMultiplexer.addProcessor(camController);
        Gdx.input.setInputProcessor(inputMultiplexer);
        controller = new UIController(worldManager);
        this.worldManager=worldManager;
    }
    private final Vector2 tmpV = new Vector2();
    public void move(float delay) {
        //cam.position.add(tmpV.set(cam.direction).scl(amount));
        //cam.update();
        controller.move(tmpV.set(moveVec).scl(movement * delay));
    }



}
